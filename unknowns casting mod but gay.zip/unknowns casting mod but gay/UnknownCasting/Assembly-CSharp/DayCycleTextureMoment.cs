using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


[Serializable]
public class DayCycleTextureMoment
{
	
	public Texture2D sunnyTex;

	
	public Texture2D cloudyTex;
}
