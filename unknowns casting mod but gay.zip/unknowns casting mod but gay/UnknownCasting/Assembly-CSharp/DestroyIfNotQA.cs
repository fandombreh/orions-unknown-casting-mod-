using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class DestroyIfNotQA : MonoBehaviour
{
	
	private void Awake()
	{
		Object.Destroy(base.gameObject);
	}
}
