using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BSPZoneData : MonoBehaviour
{
	
	
	public int Priority
	{
		get
		{
			return this.priority;
		}
	}

	
	
	public string ZoneName
	{
		get
		{
			return base.gameObject.name;
		}
	}

	
	[SerializeField]
	private int priority;

	
	[NonSerialized]
	public List<BoxCollider> boxList;
}
