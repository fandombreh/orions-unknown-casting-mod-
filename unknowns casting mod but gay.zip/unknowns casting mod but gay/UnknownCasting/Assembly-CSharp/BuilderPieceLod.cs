using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BuilderPieceLod
{
	
	public float maxDistance;

	
	public List<MeshRenderer> meshRenderers;
}
