using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class AssetContentAPI : ScriptableObject
{
	
	public string bundleName;

	
	public LazyLoadReference<TextAsset> bundleFile;

	
	public Object[] assets = new Object[0];
}
