using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class ClockController : MonoBehaviour
{
	
	public Transform Pendulum;

	
	public float MaxAngleDeflection = 10f;

	
	public float SpeedOfPendulum = 1f;
}
