using System;
using GorillaLocomotion;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BuilderSizeLayerChanger : MonoBehaviour
{
	
	
	public int SizeLayerMask
	{
		get
		{
			int num = 0;
			if (this.affectLayerA)
			{
				num |= 1;
			}
			if (this.affectLayerB)
			{
				num |= 2;
			}
			if (this.affectLayerC)
			{
				num |= 4;
			}
			if (this.affectLayerD)
			{
				num |= 8;
			}
			return num;
		}
	}

	
	private void Awake()
	{
		this.minScale = Mathf.Max(this.minScale, 0.01f);
	}

	
	public void OnTriggerEnter(Collider other)
	{
		if (other != GTPlayer.Instance.bodyCollider)
		{
			return;
		}
		VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
		if (offlineVRRig == null)
		{
			return;
		}
		if (this.applyOnTriggerEnter)
		{
			if (offlineVRRig.sizeManager.currentSizeLayerMaskValue != this.SizeLayerMask && this.fxForLayerChange != null)
			{
				ObjectPools.instance.Instantiate(this.fxForLayerChange, offlineVRRig.transform.position, true);
			}
			offlineVRRig.sizeManager.currentSizeLayerMaskValue = this.SizeLayerMask;
		}
	}

	
	public void OnTriggerExit(Collider other)
	{
		if (other != GTPlayer.Instance.bodyCollider)
		{
			return;
		}
		VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
		if (offlineVRRig == null)
		{
			return;
		}
		if (this.applyOnTriggerExit)
		{
			if (offlineVRRig.sizeManager.currentSizeLayerMaskValue != this.SizeLayerMask && this.fxForLayerChange != null)
			{
				ObjectPools.instance.Instantiate(this.fxForLayerChange, offlineVRRig.transform.position, true);
			}
			offlineVRRig.sizeManager.currentSizeLayerMaskValue = this.SizeLayerMask;
		}
	}

	
	public float maxScale;

	
	public float minScale;

	
	public bool isAssurance;

	
	public bool affectLayerA = true;

	
	public bool affectLayerB = true;

	
	public bool affectLayerC = true;

	
	public bool affectLayerD = true;

	
	[SerializeField]
	private bool applyOnTriggerEnter = true;

	
	[SerializeField]
	private bool applyOnTriggerExit;

	
	[SerializeField]
	private GameObject fxForLayerChange;
}
