using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTag;
using GorillaUtil;
using TMPro;
using Unity.Profiling;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.XR;


public class DebugHudStats : MonoBehaviour
{
	
	
	public static DebugHudStats Instance
	{
		get
		{
			return DebugHudStats._instance;
		}
	}

	
	private void Awake()
	{
		if (DebugHudStats._instance != null && DebugHudStats._instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		else
		{
			DebugHudStats._instance = this;
		}
		base.gameObject.SetActive(false);
	}

	
	private void OnDestroy()
	{
		if (DebugHudStats._instance == this)
		{
			DebugHudStats._instance = null;
			if (this.drawCallsRecorder.Valid)
			{
				this.drawCallsRecorder.Dispose();
			}
			if (this.trisRecorder.Valid)
			{
				this.trisRecorder.Dispose();
			}
		}
	}

	
	private void LateUpdate()
	{
		base.transform.LookAt(Camera.main.transform.position, Vector3.up);
		if (this.currentState == DebugHudStats.State.timeAdjust)
		{
			bool flag = ControllerInputPoller.PrimaryButtonPress(XRNode.RightHand);
			bool flag2 = ControllerInputPoller.SecondaryButtonPress(XRNode.RightHand);
			bool flag3 = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f;
			bool flag4 = ControllerInputPoller.GripFloat(XRNode.RightHand) > 0.5f;
			if (this.button1Down && !flag)
			{
				GorillaComputer.instance.AddSeverTime(flag4 ? (-60) : 60);
			}
			if (this.button2Down && !flag2)
			{
				GorillaComputer.instance.AddSeverTime(flag4 ? (-1) : 5);
			}
			if (this.button3Down && !flag3)
			{
				GorillaComputer.instance.AddSeverTime(flag4 ? (-1440) : 1440);
			}
			this.button1Down = flag;
			this.button2Down = flag2;
			this.button3Down = flag3;
		}
		if (this.currentState == DebugHudStats.State.TitleDataMonitor || this.currentState == DebugHudStats.State.ShowLog || this.currentState == DebugHudStats.State.ShowError)
		{
			bool flag5 = ControllerInputPoller.PrimaryButtonPress(XRNode.RightHand);
			bool flag6 = ControllerInputPoller.SecondaryButtonPress(XRNode.RightHand);
			if (this.button1Down && !flag5)
			{
				this.logging.pageToDisplay = ((this.logging.pageToDisplay < this.logging.textInfo.pageCount) ? (this.logging.pageToDisplay + 1) : 1);
				this.updateLogTitle();
			}
			if (this.button2Down && !flag6)
			{
				this.logging.pageToDisplay = ((this.logging.pageToDisplay > 1) ? (this.logging.pageToDisplay - 1) : this.logging.textInfo.pageCount);
				this.updateLogTitle();
			}
			this.button1Down = flag5;
			this.button2Down = flag6;
		}
		bool flag7 = ControllerInputPoller.SecondaryButtonPress(XRNode.LeftHand);
		bool flag8 = ControllerInputPoller.PrimaryButtonPress(XRNode.LeftHand);
		if ((this.buttonDown && !flag7) || (this.buttonDownBack && !flag8))
		{
			this.NextState(this.buttonDown);
			if (this.currentState == DebugHudStats.State.ShowStats)
			{
				this.distanceMoved = (this.distanceSwam = 0f);
				PlayerGameEvents.OnPlayerMoved += this.OnPlayerMoved;
				PlayerGameEvents.OnPlayerSwam += this.OnPlayerSwam;
			}
			this.text.gameObject.SetActive(this.currentState > DebugHudStats.State.Inactive);
			if (RigidbodyHighlighter.Instance != null)
			{
				RigidbodyHighlighter.Instance.Active = this.currentState == DebugHudStats.State.ShowRBs;
			}
		}
		this.buttonDown = flag7;
		this.buttonDownBack = flag8;
		if (this.firstAwake == 0f)
		{
			this.firstAwake = Time.time;
		}
		if (this.updateTimer < this.delayUpdateRate)
		{
			this.updateTimer += Time.deltaTime;
			return;
		}
		int num = Mathf.RoundToInt(1f / Time.smoothDeltaTime);
		if (num < DebugHudStats.FPS_THRESHOLD)
		{
			this.lowFps++;
		}
		else
		{
			this.lowFps = 0;
		}
		this.fpsWarning.gameObject.SetActive(this.lowFps > 5 && this.currentState == DebugHudStats.State.Inactive);
		if (this.currentState != DebugHudStats.State.Inactive)
		{
			this.builder.Clear();
			this.builder.Append("gt: ");
			this.builder.Append(GorillaComputer.instance.version);
			this.builder.Append(":");
			this.builder.Append(GorillaComputer.instance.buildCode);
			this.builder.AppendLine(this.spoofIds ? " <color=\"red\">*Spoofing IDs*</color>" : string.Empty);
			num = Mathf.Min(num, 90);
			this.builder.Append((num < DebugHudStats.FPS_THRESHOLD) ? "<color=\"red\">" : "<color=\"white\">");
			this.builder.Append(num);
			this.builder.Append(string.Format(" fps / {0} fps</color> ", DebugHudStats.FPS_THRESHOLD + 1));
			this.builder.AppendLine(string.Format("sfps: {0} (Health: {1})", GorillaTagger.Instance.SmoothedFramerate, GorillaTagger.Instance.FramerateHealth));
			float eyeTextureResolutionScale = XRSettings.eyeTextureResolutionScale;
			float renderViewportScale = XRSettings.renderViewportScale;
			float renderScale = (GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset).renderScale;
			this.builder.AppendLine(string.Format("draw calls: {0} tris: {1} ", this.drawCallsRecorder.LastValue, this.trisRecorder.LastValue) + string.Format("rs: {0}/{1}/{2} ", eyeTextureResolutionScale, renderViewportScale, renderScale));
			if (GorillaComputer.instance != null)
			{
				DateTime serverTime = GorillaComputer.instance.GetServerTime();
				this.builder.AppendLine(string.Format("<color={0}>{1}</color>", (serverTime.Year > 2020) ? "#00FFAA" : "#FF3333", serverTime));
			}
			else
			{
				this.builder.AppendLine("<color=#FF3333>Server Time Unavailable</color>");
			}
			ZoneDef currentNode = GorillaTagger.Instance.offlineVRRig.zoneEntity.currentNode;
			if (currentNode != null)
			{
				this.zones = string.Format("{0}/{1}/{2}", currentNode.gameObject.name.ToUpperInvariant(), currentNode.zoneId, currentNode.subZoneId);
			}
			if (NetworkSystem.Instance.IsMasterClient)
			{
				this.builder.Append("H");
			}
			if (NetworkSystem.Instance.InRoom)
			{
				if (NetworkSystem.Instance.SessionIsPrivate)
				{
					this.builder.Append("Pri ");
				}
				else
				{
					this.builder.Append("Pub ");
				}
			}
			else
			{
				this.builder.Append("DC ");
			}
			this.builder.Append("z: <color=\"green\">");
			this.builder.Append(this.zones);
			this.builder.AppendLine("</color>");
			if (NetworkSystem.Instance.InRoom)
			{
				GorillaGameManager instance = GorillaGameManager.instance;
				if (instance != null)
				{
					GorillaTagCompetitiveManager gorillaTagCompetitiveManager = instance as GorillaTagCompetitiveManager;
					if (gorillaTagCompetitiveManager != null)
					{
						this.builder.Append("Ranked Mode ELO: ");
						this.builder.Append(gorillaTagCompetitiveManager.GetScoring().Progression.GetEloScore().ToString());
						this.builder.Append("  Tier: ");
						this.builder.AppendLine(gorillaTagCompetitiveManager.GetScoring().Progression.GetRankedProgressionTierName());
						RankedMultiplayerScore.PlayerScoreInRound inGameScoreForSelf = gorillaTagCompetitiveManager.GetScoring().GetInGameScoreForSelf();
						this.builder.Append("Tags: ");
						this.builder.Append(inGameScoreForSelf.NumTags.ToString());
						this.builder.Append("  Defense: ");
						this.builder.Append(Mathf.RoundToInt(inGameScoreForSelf.PointsOnDefense).ToString());
						this.builder.Append("  Score: ");
						this.builder.AppendLine(Mathf.RoundToInt(gorillaTagCompetitiveManager.GetScoring().ComputeGameScore(inGameScoreForSelf.NumTags, inGameScoreForSelf.PointsOnDefense)).ToString());
						if (gorillaTagCompetitiveManager.ShowDebugPing)
						{
							this.builder.AppendLine("Server MatchID Ping!");
						}
					}
				}
			}
			switch (this.currentState)
			{
			case DebugHudStats.State.ShowStats:
			{
				this.builder.AppendLine("\nStats:\n");
				Vector3 vector = GTPlayer.Instance.AveragedVelocity;
				Vector3 headCenterPosition = GTPlayer.Instance.HeadCenterPosition;
				float magnitude = vector.magnitude;
				this.groundVelocity = vector;
				this.groundVelocity.y = 0f;
				this.builder.AppendLine(string.Format("v: {0:F1} m/s\t\todo: {1:F2}m\tswam: {2:F2}m", magnitude, this.distanceMoved, this.distanceSwam));
				this.builder.AppendLine(string.Format("ground: {0:F1} m/s\thead: {1:F2}", this.groundVelocity.magnitude, headCenterPosition));
				break;
			}
			case DebugHudStats.State.ShowRBs:
				this.builder.AppendLine("\nRigid Body Locator\n");
				break;
			case DebugHudStats.State.timeAdjust:
				this.builder.AppendLine("\nAdjust Time:\n");
				this.builder.AppendLine("Press [A] to advance one hour [+ R Grip to go back one hour]");
				this.builder.AppendLine("Press [B] to advance five minutes [+ R Grip to go back one minute]");
				this.builder.AppendLine("Press [R] Trigger to advance one day [+ R Grip to go back one day]");
				break;
			case DebugHudStats.State.RecordingMode:
				this.builder.AppendLine("\nMo-Cap Recording:\n");
				break;
			}
			this.text.text = this.builder.ToString();
		}
		this.updateTimer = 0f;
	}

	
	private void NextState(bool fwd)
	{
		PlayerGameEvents.OnPlayerMoved -= this.OnPlayerMoved;
		PlayerGameEvents.OnPlayerSwam -= this.OnPlayerSwam;
		this.logging.gameObject.SetActive(false);
		this.logging.pageToDisplay = 1;
		switch (this.currentState)
		{
		case DebugHudStats.State.Inactive:
			this.currentState = (fwd ? DebugHudStats.State.Active : DebugHudStats.State.timeAdjust);
			break;
		case DebugHudStats.State.Active:
			this.currentState = (fwd ? DebugHudStats.State.ShowLog : DebugHudStats.State.Inactive);
			break;
		case DebugHudStats.State.ShowLog:
			this.currentState = (fwd ? DebugHudStats.State.ShowError : DebugHudStats.State.Active);
			break;
		case DebugHudStats.State.ShowError:
			this.currentState = (fwd ? DebugHudStats.State.ShowStats : DebugHudStats.State.ShowLog);
			break;
		case DebugHudStats.State.ShowStats:
			this.currentState = (fwd ? DebugHudStats.State.ShowRBs : DebugHudStats.State.ShowError);
			break;
		case DebugHudStats.State.ShowRBs:
			this.currentState = (fwd ? DebugHudStats.State.TitleDataMonitor : DebugHudStats.State.ShowStats);
			break;
		case DebugHudStats.State.timeAdjust:
			this.currentState = (fwd ? DebugHudStats.State.Inactive : DebugHudStats.State.TitleDataMonitor);
			break;
		case DebugHudStats.State.RecordingMode:
			this.currentState = (fwd ? DebugHudStats.State.Inactive : DebugHudStats.State.timeAdjust);
			break;
		case DebugHudStats.State.TitleDataMonitor:
			this.currentState = (fwd ? DebugHudStats.State.timeAdjust : DebugHudStats.State.ShowRBs);
			break;
		}
		this.UpdateLog();
	}

	
	private void DisplayLog(List<string> log)
	{
		this.logging.gameObject.SetActive(true);
		this.logging.text = string.Empty;
		for (int i = log.Count - 1; i >= 0; i--)
		{
			TMP_Text tmp_Text = this.logging;
			tmp_Text.text = tmp_Text.text + log[i] + "\n";
		}
		this.updateLogTitle();
	}

	
	private async void updateLogTitle()
	{
		await Task.Yield();
		this.logPage.text = string.Format("{0} <<[B] turn page [A]>> ({1}/{2})", this.logTitleFromState(this.currentState), this.logging.pageToDisplay, this.logging.textInfo.pageCount);
	}

	
	private string logTitleFromState(DebugHudStats.State s)
	{
		if (s == DebugHudStats.State.ShowLog)
		{
			return "Debug Log";
		}
		if (s == DebugHudStats.State.ShowError)
		{
			return "Error Log";
		}
		if (s != DebugHudStats.State.TitleDataMonitor)
		{
			return string.Empty;
		}
		return "Title Data Log";
	}

	
	private string colorFromState(DebugHudStats.State s)
	{
		switch (s)
		{
		case DebugHudStats.State.ShowLog:
			return "\"yellow\"";
		case DebugHudStats.State.ShowError:
			return "\"orange\"";
		case DebugHudStats.State.ShowStats:
			return "\"green\"";
		case DebugHudStats.State.ShowRBs:
			return "\"red\"";
		case DebugHudStats.State.RecordingMode:
			return "\"purple\"";
		case DebugHudStats.State.TitleDataMonitor:
			return "#00ffff";
		}
		return "#ffffff";
	}

	
	private void OnPlayerSwam(float distance, float speed)
	{
		if (distance > 0.005f)
		{
			this.distanceSwam += distance;
		}
	}

	
	private void OnPlayerMoved(float distance, float speed)
	{
		if (distance > 0.005f)
		{
			this.distanceMoved += distance;
		}
	}

	
	private void OnEnable()
	{
		Application.logMessageReceived += this.LogMessageReceived;
		PlayFabTitleDataCache.OnValueRetieved = (Action<string, string>)Delegate.Combine(PlayFabTitleDataCache.OnValueRetieved, new Action<string, string>(this.TDValueRetrieved));
		PlayFabTitleDataCache.OnCachedValueRetieved = (Action<string, string>)Delegate.Combine(PlayFabTitleDataCache.OnCachedValueRetieved, new Action<string, string>(this.TDCachedValueRetrieved));
	}

	
	private void TDValueRetrieved(string arg1, string arg2)
	{
		this.logTD.Add(string.Format(" >{0:F2}> TitleData[ <color=#ffaaff>{1}</color> ] = {2}", Time.realtimeSinceStartup, arg1, arg2));
		if (this.logTD.Count > 1000)
		{
			this.logTD.RemoveAt(0);
		}
		this.UpdateLog();
	}

	
	private void TDCachedValueRetrieved(string arg1, string arg2)
	{
		this.logTD.Add(string.Format(" >{0:F2}> TitleData[ <color=#00ffff>{1}</color> ] = {2}", Time.realtimeSinceStartup, arg1, arg2));
		if (this.logTD.Count > 1000)
		{
			this.logTD.RemoveAt(0);
		}
		this.UpdateLog();
	}

	
	private void OnDisable()
	{
		PlayFabTitleDataCache.OnValueRetieved = (Action<string, string>)Delegate.Remove(PlayFabTitleDataCache.OnValueRetieved, new Action<string, string>(this.TDValueRetrieved));
		PlayFabTitleDataCache.OnCachedValueRetieved = (Action<string, string>)Delegate.Remove(PlayFabTitleDataCache.OnCachedValueRetieved, new Action<string, string>(this.TDCachedValueRetrieved));
		Application.logMessageReceived -= this.LogMessageReceived;
	}

	
	private void LogMessageReceived(string condition, string stackTrace, LogType type)
	{
		string text = string.Format(" >{0:F2}> {1}{2}</color>", Time.realtimeSinceStartup, this.getColorStringFromLogType(type), condition);
		if (this.pLog != condition)
		{
			this.logMessage.Add(text);
		}
		else
		{
			this.logMessage[this.logMessage.Count - 1] = text;
		}
		this.pLog = condition;
		if (this.logMessage.Count > 1000)
		{
			this.logMessage.RemoveAt(0);
		}
		if (type == LogType.Error || type == LogType.Assert || type == LogType.Exception)
		{
			this.logError.Add(text + "\n" + stackTrace);
			if (this.logError.Count > 1000)
			{
				this.logError.RemoveAt(0);
			}
		}
		this.UpdateLog();
	}

	
	private void UpdateLog()
	{
		DebugHudStats.State state = this.currentState;
		if (state == DebugHudStats.State.ShowLog)
		{
			this.DisplayLog(this.logMessage);
			return;
		}
		if (state == DebugHudStats.State.ShowError)
		{
			this.DisplayLog(this.logError);
			return;
		}
		if (state != DebugHudStats.State.TitleDataMonitor)
		{
			return;
		}
		this.DisplayLog(this.logTD);
	}

	
	private string getColorStringFromLogType(LogType type)
	{
		switch (type)
		{
		case LogType.Error:
		case LogType.Assert:
		case LogType.Exception:
			return "<color=\"red\">";
		case LogType.Warning:
			return "<color=\"yellow\">";
		}
		return "<color=\"white\">";
	}

	
	private void OnZoneChanged(ZoneData[] zoneData)
	{
		this.zones = string.Empty;
		for (int i = 0; i < zoneData.Length; i++)
		{
			if (zoneData[i].active)
			{
				this.zones = this.zones + zoneData[i].zone.ToString().ToUpper() + "; ";
			}
		}
	}

	
	public static int FPS_THRESHOLD = 89;

	
	private static DebugHudStats _instance;

	
	[SerializeField]
	public TMP_Text text;

	
	[SerializeField]
	public TMP_Text logging;

	
	[SerializeField]
	public TMP_Text logPage;

	
	[SerializeField]
	private TMP_Text fpsWarning;

	
	[SerializeField]
	private float delayUpdateRate = 0.25f;

	
	private float updateTimer;

	
	public float sessionAnytrackingLost;

	
	public float last30SecondsTrackingLost;

	
	private float firstAwake;

	
	private bool leftHandTracked;

	
	private bool rightHandTracked;

	
	private StringBuilder builder;

	
	private Vector3 averagedVelocity;

	
	private Vector3 groundVelocity;

	
	private Vector3 centerHeadPos;

	
	private float distanceMoved;

	
	private float distanceSwam;

	
	private List<string> logMessage = new List<string>();

	
	private List<string> logError = new List<string>();

	
	private List<string> logTD = new List<string>();

	
	private bool buttonDown;

	
	private bool buttonDownBack;

	
	private bool spoofIds;

	
	private int lowFps;

	
	private string zones;

	
	private GroupJoinZoneAB lastGroupJoinZone;

	
	private DebugHudStats.State currentState = DebugHudStats.State.Active;

	
	private ProfilerRecorder drawCallsRecorder;

	
	private ProfilerRecorder trisRecorder;

	
	private string pLog;

	
	private bool button1Down;

	
	private bool button2Down;

	
	private bool button3Down;

	
	[SerializeField]
	private StringTable betaTitleDataOveride;

	
	private enum State
	{
		
		Inactive,
		
		Active,
		
		ShowLog,
		
		ShowError,
		
		ShowStats,
		
		ShowRBs,
		
		timeAdjust,
		
		RecordingMode,
		
		TitleDataMonitor
	}
}
