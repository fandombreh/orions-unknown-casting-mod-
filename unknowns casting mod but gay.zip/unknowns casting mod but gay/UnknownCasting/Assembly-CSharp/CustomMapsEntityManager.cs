using System;
using Fusion;
using GorillaNetworking;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


[NetworkBehaviourWeaved(0)]
public class CustomMapsEntityManager : GameEntityManager
{
	
	private static bool IsOverrideEnabled()
	{
		GorillaServer instance = GorillaServer.Instance;
		return instance != null && instance.CheckIsVStumpGrabbablesFixEnabled();
	}

	
	public override bool IsPositionInManagerBounds(Vector3 pos)
	{
		return (CustomMapLoader.CanLoadEntities && CustomMapsEntityManager.IsOverrideEnabled()) || base.IsPositionInManagerBounds(pos);
	}

	
	protected override bool IsInZone()
	{
		if (!CustomMapLoader.CanLoadEntities || !CustomMapsEntityManager.IsOverrideEnabled())
		{
			return base.IsInZone();
		}
		bool flag = true;
		for (int i = 0; i < this.zoneComponents.Count; i++)
		{
			flag &= this.zoneComponents[i].IsZoneReady();
		}
		return flag;
	}

	
	[WeaverGenerated]
	public override void CopyBackingFieldsToState(bool A_1)
	{
		base.CopyBackingFieldsToState(A_1);
	}

	
	[WeaverGenerated]
	public override void CopyStateToBackingFields()
	{
		base.CopyStateToBackingFields();
	}
}
