using System;
using System.Diagnostics;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;

namespace BuildSafe
{
	
	public static class EditorGUIUtility
	{
		
		[Conditional("UNITY_EDITOR")]
		public static void PingObject(Object obj)
		{
		}
	}
}
