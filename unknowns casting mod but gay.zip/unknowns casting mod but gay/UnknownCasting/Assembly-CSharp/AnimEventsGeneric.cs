using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;
using UnityEngine.Events;


public class AnimEventsGeneric : MonoBehaviour
{
	
	public void Event1()
	{
		this.event1.Invoke();
	}

	
	public void Event2()
	{
		this.event2.Invoke();
	}

	
	public void Event3()
	{
		this.event3.Invoke();
	}

	
	public void Event4()
	{
		this.event4.Invoke();
	}

	
	public void Event5()
	{
		this.event5.Invoke();
	}

	
	public void Event6()
	{
		this.event6.Invoke();
	}

	
	public void Event7()
	{
		this.event7.Invoke();
	}

	
	public void Event8()
	{
		this.event8.Invoke();
	}

	
	public void Event9()
	{
		this.event9.Invoke();
	}

	
	public void Event10()
	{
		this.event10.Invoke();
	}

	
	[SerializeField]
	private UnityEvent event1;

	
	[SerializeField]
	private UnityEvent event2;

	
	[SerializeField]
	private UnityEvent event3;

	
	[SerializeField]
	private UnityEvent event4;

	
	[SerializeField]
	private UnityEvent event5;

	
	[SerializeField]
	private UnityEvent event6;

	
	[SerializeField]
	private UnityEvent event7;

	
	[SerializeField]
	private UnityEvent event8;

	
	[SerializeField]
	private UnityEvent event9;

	
	[SerializeField]
	private UnityEvent event10;
}
