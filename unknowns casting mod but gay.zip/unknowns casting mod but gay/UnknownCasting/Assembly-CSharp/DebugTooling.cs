using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class DebugTooling : MonoBehaviour
{
	
	public enum DebugScreen
	{
		
		KID,
		
		Localization
	}
}
