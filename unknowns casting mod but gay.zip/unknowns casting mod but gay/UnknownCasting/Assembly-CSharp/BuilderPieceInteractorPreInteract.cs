using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BuilderPieceInteractorPreInteract : MonoBehaviour
{
	
	private void Awake()
	{
	}

	
	private void LateUpdate()
	{
	}

	
	public BuilderPieceInteractor interactor;
}
