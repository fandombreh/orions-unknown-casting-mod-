using System;
using Unity.Burst;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


internal static class $BurstDirectCallInitializer
{
	
	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterAssembliesLoaded)]
	private static void Initialize()
	{
		BurstCompilerOptions options = BurstCompiler.Options;
	}
}
