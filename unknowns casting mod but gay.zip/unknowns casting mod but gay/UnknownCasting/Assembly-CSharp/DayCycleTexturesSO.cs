using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


[CreateAssetMenu(fileName = "DayCycleTextures", menuName = "Gorilla Tag/Day Cycle Textures", order = 0)]
public class DayCycleTexturesSO : ScriptableObject
{
	
	public DayCycleTextureMoment[] moments = new DayCycleTextureMoment[10];
}
