using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class CritterSpawnCriteria : ScriptableObject
{
	
	public bool CanSpawn()
	{
		if (this.spawnTimings.Length == 0)
		{
			return true;
		}
		string currentTimeOfDay = BetterDayNightManager.instance.currentTimeOfDay;
		string[] array = this.spawnTimings;
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i] == currentTimeOfDay)
			{
				return true;
			}
		}
		return false;
	}

	
	public string[] spawnTimings;
}
