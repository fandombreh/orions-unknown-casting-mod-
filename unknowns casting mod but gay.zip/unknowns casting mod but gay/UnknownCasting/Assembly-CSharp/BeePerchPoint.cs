using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BeePerchPoint : MonoBehaviour
{
	
	public Vector3 GetPoint()
	{
		return base.transform.TransformPoint(this.localPosition);
	}

	
	[SerializeField]
	private Vector3 localPosition;
}
