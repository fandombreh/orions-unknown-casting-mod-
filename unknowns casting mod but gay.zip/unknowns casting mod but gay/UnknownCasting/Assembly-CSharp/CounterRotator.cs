using System;
using GorillaTag.Gravity;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class CounterRotator : MonoBehaviour
{
	
	private void Start()
	{
		this.startingPosition = this.stabilizedObject.transform.position;
		this.startingRotation = this.stabilizedObject.transform.rotation;
	}

	
	private void LateUpdate()
	{
		Quaternion quaternion = this.startingRotation * Quaternion.Inverse(this.stabilizedObject.transform.rotation);
		base.transform.rotation = quaternion * base.transform.rotation;
		Vector3 vector = this.startingPosition - this.stabilizedObject.transform.position;
		base.transform.position += vector;
		if (this.gravityCompensator != null)
		{
			this.gravityCompensator.SetGravityDirection(-base.transform.up);
		}
	}

	
	[SerializeField]
	private GameObject stabilizedObject;

	
	[SerializeField]
	private ChangingBasicGravityZone gravityCompensator;

	
	private Vector3 startingPosition;

	
	private Quaternion startingRotation;
}
