using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


[DisallowMultipleComponent]
public class CubemapRenderer : MonoBehaviour
{
}
