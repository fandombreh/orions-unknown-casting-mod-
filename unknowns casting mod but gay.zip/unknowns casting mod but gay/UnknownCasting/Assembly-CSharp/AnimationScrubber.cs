using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class AnimationScrubber : MonoBehaviour
{
	
	private void LateUpdate()
	{
		if (!this.scrubberActive)
		{
			return;
		}
		AnimatorStateInfo currentAnimatorStateInfo = this.targetAnimator.GetCurrentAnimatorStateInfo(0);
		AnimatorClipInfo[] currentAnimatorClipInfo = this.targetAnimator.GetCurrentAnimatorClipInfo(0);
		this.targetAnimator.Play(currentAnimatorClipInfo[0].clip.name, 0, this.animationPlaybackTime / currentAnimatorStateInfo.length);
	}

	
	public bool scrubberActive;

	
	public float animationPlaybackTime;

	
	public Animator targetAnimator;
}
