using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BuilderPieceCollider : MonoBehaviour
{
	
	public BuilderPiece piece;
}
