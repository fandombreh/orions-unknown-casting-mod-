using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


[Serializable]
public struct BuilderResourceColor
{
	
	public BuilderResourceType type;

	
	public Color color;
}
