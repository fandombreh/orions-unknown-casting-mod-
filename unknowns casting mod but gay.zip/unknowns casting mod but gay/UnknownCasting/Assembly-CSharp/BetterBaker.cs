using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BetterBaker : MonoBehaviour
{
	
	public string bakeryLightmapDirectory;

	
	public string dayNightLightmapsDirectory;

	
	public GameObject[] allLights;

	
	public struct LightMapMap
	{
		
		public string timeOfDayName;

		
		public GameObject lightObject;
	}
}
