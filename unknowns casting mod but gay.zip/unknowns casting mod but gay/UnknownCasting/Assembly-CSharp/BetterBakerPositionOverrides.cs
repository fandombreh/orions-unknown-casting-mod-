using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class BetterBakerPositionOverrides : MonoBehaviour
{
	
	public List<BetterBakerPositionOverrides.OverridePosition> overridePositions;

	
	[Serializable]
	public struct OverridePosition
	{
		
		public GameObject go;

		
		public Transform bakingTransform;

		
		public Transform gameTransform;
	}
}
