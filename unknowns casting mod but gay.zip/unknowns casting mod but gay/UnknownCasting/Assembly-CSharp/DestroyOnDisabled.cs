using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class DestroyOnDisabled : MonoBehaviour
{
	
	private void OnDisable()
	{
		Object.Destroy(base.gameObject);
	}
}
