using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public abstract class CustomMapsBehaviourBase
{
	
	public abstract bool CanExecute();

	
	public abstract void Execute();

	
	public abstract void NetExecute();

	
	public abstract void ResetBehavior();

	
	public abstract bool CanContinueExecuting();

	
	public abstract void OnTriggerEnter(Collider otherCollider);
}
