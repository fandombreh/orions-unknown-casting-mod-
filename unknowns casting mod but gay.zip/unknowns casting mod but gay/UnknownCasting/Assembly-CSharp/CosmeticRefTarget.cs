using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


public class CosmeticRefTarget : MonoBehaviour
{
	
	public CosmeticRefID id;
}
