using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;


[CreateAssetMenu(fileName = "BuilderMaterialResources", menuName = "Gorilla Tag/Builder/Resources", order = 0)]
public class BuilderResources : ScriptableObject
{
	
	public List<BuilderResourceQuantity> quantities;
}
