using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;

namespace CosmeticRoom.ItemScripts
{
	
	public class TrickTreatHoldable : TransferrableObject
	{
		
		protected override void LateUpdateLocal()
		{
			base.LateUpdateLocal();
			if (this.candyCollider)
			{
				this.candyCollider.enabled = this.IsMyItem() && this.IsHeld();
			}
		}

		
		public MeshCollider candyCollider;
	}
}
