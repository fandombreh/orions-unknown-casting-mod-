using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;

namespace com.AnotherAxiom.Paddleball
{
	
	public class PaddleballPaddle : MonoBehaviour
	{
		
		
		public bool Right
		{
			get
			{
				return this.right;
			}
		}

		
		[SerializeField]
		private bool right;
	}
}
