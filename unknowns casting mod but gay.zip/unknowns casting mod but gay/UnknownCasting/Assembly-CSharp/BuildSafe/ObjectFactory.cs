using System;
using UnityEngine;
using Random = UnityEngine.Random;
using Object = UnityEngine.Object;

namespace BuildSafe
{
	
	public static class ObjectFactory
	{
		
		
		
		public static event Action<Component> componentWasAdded
		{
			add
			{
			}
			remove
			{
			}
		}
	}
}
